<?php

namespace App\Http\Controllers;

use App\User;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

//use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    //
    public function index($user)
    {


        $user = \App\User::findOrFail($user);
//        ddd($user, $user->page);

//        dd($user->page()->title());
//        dd($user_id);
//        dd(User::find($user_id));
//        $user = User::findOrFail($user_id);
        $page = $user->page;
        $follows = (auth()->user()) ? auth()->user()->following->contains($user->id) : false;
//        ddd($follows);
        return view('pages.index', compact('user', 'page', 'follows'));
    }

    public function edit($user){
//        dd($user);
//        $user = auth()->user()->page->($user);
        $user = \App\User::findOrFail($user);
//        ddd($user);
        if (Gate::denies('update', $user->page)) {
            abort(401);
        }

//        if ($user->cannot('update', $page)) {
//            abort(404);
//        }

//        if ($user->)
//        $user = Auth::user();

//        $this->authorizeForUser($user, 'update');

        return view('pages.edit', compact('user'));

//        dd($user->page->title);
//        dd($user->posts());

    }

    public function update($user, Request $request){
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'url' => ['required', 'url'],
//            'image' => ['required', 'image' ]
        ]);
//        $path = Storage::disk('public')->put('uploads', $request->file('image'));
//
//        $image = Image::make(public_path("storage/{$path}"))->fit(200, 200);
//        $image->save();
//        ddd($data, $user);

        $user = \App\User::findOrFail($user);
        $page = $user->page;
//        ddd($user);

        if (Gate::denies('update', $page)) {

            abort(401);
        }
        $data['title'] = $data['title'];
        $data['description'] = $data['description'];
        $data['url'] = $data['url'];

        if (request('image')){
            $path = Storage::disk('public')->put('page', $request->file('image'));

            $image = Image::make(public_path("storage/{$path}"))->fit(300, 300);

            $image->save();
            $imageArray = ['image' => $path];

        }
        auth()->user()->page->update(
          array_merge(
              $data,
              $imageArray ?? []
          )
        );
//        $page->push();
        return redirect('/page/' . $user->id);
    }
}
