<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-3">
                <div class="col-8 mx-auto">
                    <p class="mb-0">
                        <a href="/page/<?php echo e($post->user->id); ?>">
                            <strong>
                                <?php echo e($post->user->username); ?>

                            </strong>
                        </a>
                        wrote:
                        <?php echo e($post->caption); ?></p>

                    <a href="/post/<?php echo e($post->id); ?>">
                        <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
                    </a>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row justify-content-center">
            <div class="col-8 ">
                <?php echo e($posts->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/laravel/blog/resources/views/posts/index.blade.php ENDPATH**/ ?>