<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-8">
                <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
            </div>
            <div class="col-4">
                <div class="d-flex">
                    <div class="image" style="max-width: 48px;">
                        <img class="rounded-circle w-100"
                             src="<?php echo e($post->user->page->image); ?>"
                             alt="<?php echo e($post->user->page->name); ?>">
                    </div>
                    <div class="details d-flex flex-column ml-3 justify-content-center">
                        <a href="/page/<?php echo e($post->user->id); ?>" class="font-weight-bold username"><?php echo e($post->user->username); ?></a>
                        <span href="#" class="title" style="line-height: 12px"><?php echo e($post->user->page->title); ?></span>
                    </div>

                    <a class="d-inline-flex justify-content-center align-items-center ml-3 font-weight-bold h5" href="/follow/<?php echo e($post->user->id); ?>"
                       class="follow_btn">
                        Follow
                    </a>


                </div>

                <hr/>
                <p>
                    <strong>
                        <?php echo e($post->user->username); ?>

                    </strong>
                    wrote:
                    <?php echo e($post->caption); ?></p>
            </div>
        </div>

        <div class="row mt-4">
            <?php $__currentLoopData = $post->user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4 mb-4">
                    <a href="/post/<?php echo e($post->id); ?>">
                        <img class="w-100" src="/storage/<?php echo e($post->image); ?>">
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/laravel/blog/resources/views/posts/show.blade.php ENDPATH**/ ?>