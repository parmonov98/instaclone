<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
       <div class="col-3 p-5">
            <img class="rounded-circle w-100" src="<?php echo e($user->page->profileImage()); ?>" >
       </div>
       <div class="col-9 pt-5">
            <h3 class="d-flex justify-aligns-center">
                <strong><?php echo e($user->username); ?></strong>
                <follow-button user-id = <?php echo e($user->id); ?> follows=<?php echo e($follows); ?>></follow-button>
                <?php echo e($user->id); ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $page)): ?>
                    <a href="/post/create" class="ml-auto h5">Add post</a>
                <?php endif; ?>
            </h3>
           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $page)): ?>
               <a href="/page/<?php echo e($user->id); ?>/edit" class="mr-auto h5">Edit page</a>
           <?php endif; ?>
            <div class="mt-2">
                <strong><?php echo e($user->posts->count()); ?></strong> posts
                <strong class="ml-4"><?php echo e($user->page->followers->count()); ?></strong> followers
                <strong class="ml-4"><?php echo e($user->following->count()); ?></strong> following
            </div>
            <div class="mt-3">
                <strong><?php echo e($user->page->title); ?></strong>
            </div>
            <div>
                <?php echo e($user->page->description); ?>

            </div>
            <div><a href="<?php echo e($user->page->url ?? '#'); ?>"><?php echo e($user->page->url ?? 'N/A'); ?></a></div>
       </div>
    </div>

    <div class="row mt-4">
        <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-md-6 col-lg-4 mb-3 post_item">
                <img class="w-100" src="/storage/<?php echo e($post->image); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                    <a class="delete_post" href="/post/<?php echo e($post->id); ?>/delete">
                        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-x-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                            <path fill-rule="evenodd" d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                        </svg>
                    </a>
                <?php endif; ?>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/laravel/blog/resources/views/pages/index.blade.php ENDPATH**/ ?>